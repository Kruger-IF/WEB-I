@extends('layouts.app')
@section('content')
<div class="card"><div class="card-body">
    <h4 class="mb-3">{{ $servico->exists ? 'Editar' : 'Novo' }} serviço</h4>
    <form method="POST" action="{{ $servico->exists ? route('servicos.update', $servico->id) : route('servicos.store') }}">
        @csrf @if($servico->exists) @method('PUT') @endif
        <div class="row g-3">
            <div class="col-md-7"><label class="form-label">Nome</label>
                <input name="nome" class="form-control" value="{{ old('nome', $servico->nome) }}" required></div>
            <div class="col-md-3"><label class="form-label">Valor (R$)</label>
                <input type="number" step="0.01" name="valor" class="form-control" value="{{ old('valor', $servico->valor) }}" required></div>
        </div>
        <div class="mt-4"><button class="btn btn-primary"><i class="bi bi-save"></i> Salvar</button>
            <a href="{{ route('servicos.index') }}" class="btn btn-outline-secondary">Cancelar</a></div>
    </form>
</div></div>
@endsection
