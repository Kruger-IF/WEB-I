@extends('layouts.app')
@section('content')
<div class="card"><div class="card-body">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <h4 class="mb-0"><i class="bi bi-tools"></i> Serviços</h4>
        <a href="{{ route('servicos.create') }}" class="btn btn-success"><i class="bi bi-plus-lg"></i> Novo serviço</a>
    </div>
    @include('layouts._search', ['placeholder' => 'Pesquisar por nome do serviço...'])
    <div class="table-responsive mt-3">
    <table class="table table-hover align-middle">
        <thead><tr><th>Serviço</th><th>Valor</th><th>Usado em ordens</th><th></th></tr></thead>
        <tbody>
        @forelse($servicos as $s)
            <tr>
                <td>{{ $s->nome }}</td>
                <td>R$ {{ number_format($s->valor, 2, ',', '.') }}</td>
                <td><span class="badge bg-secondary">{{ $s->ordens_count }}</span></td>
                @include('layouts._actions', ['rota' => 'servicos', 'item' => $s])
            </tr>
        @empty
            <tr><td colspan="4" class="text-center text-muted py-4">Nenhum registro encontrado.</td></tr>
        @endforelse
        </tbody>
    </table></div>
    {{ $servicos->links('pagination::bootstrap-5') }}
</div></div>
@endsection
