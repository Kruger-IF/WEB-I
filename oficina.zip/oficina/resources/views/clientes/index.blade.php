@extends('layouts.app')
@section('content')
<div class="card"><div class="card-body">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <h4 class="mb-0"><i class="bi bi-people"></i> Clientes</h4>
        <a href="{{ route('clientes.create') }}" class="btn btn-success"><i class="bi bi-plus-lg"></i> Novo cliente</a>
    </div>
    @include('layouts._search', ['placeholder' => 'Pesquisar por nome, CPF ou telefone...'])
    <div class="table-responsive mt-3">
    <table class="table table-hover align-middle">
        <thead><tr><th>Nome</th><th>CPF</th><th>Telefone</th><th>Veículos</th><th></th></tr></thead>
        <tbody>
        @forelse($clientes as $c)
            <tr>
                <td>{{ $c->nome }}</td><td>{{ $c->cpf }}</td><td>{{ $c->telefone }}</td>
                <td><span class="badge bg-secondary">{{ $c->veiculos_count }}</span></td>
                @include('layouts._actions', ['rota' => 'clientes', 'item' => $c])
            </tr>
        @empty
            <tr><td colspan="5" class="text-center text-muted py-4">Nenhum registro encontrado.</td></tr>
        @endforelse
        </tbody>
    </table></div>
    {{ $clientes->links('pagination::bootstrap-5') }}
</div></div>
@endsection
