@extends('layouts.app')
@section('content')
<div class="card"><div class="card-body">
    <h4 class="mb-3">{{ $cliente->exists ? 'Editar' : 'Novo' }} cliente</h4>
    <form method="POST" action="{{ $cliente->exists ? route('clientes.update', $cliente->id) : route('clientes.store') }}">
        @csrf @if($cliente->exists) @method('PUT') @endif
        <div class="row g-3">
            <div class="col-md-6"><label class="form-label">Nome</label>
                <input name="nome" class="form-control" value="{{ old('nome', $cliente->nome) }}" required></div>
            <div class="col-md-3"><label class="form-label">CPF</label>
                <input name="cpf" class="form-control" value="{{ old('cpf', $cliente->cpf) }}" required></div>
            <div class="col-md-3"><label class="form-label">Telefone</label>
                <input name="telefone" class="form-control" value="{{ old('telefone', $cliente->telefone) }}" required></div>
        </div>
        <div class="mt-4"><button class="btn btn-primary"><i class="bi bi-save"></i> Salvar</button>
            <a href="{{ route('clientes.index') }}" class="btn btn-outline-secondary">Cancelar</a></div>
    </form>
</div></div>
@endsection
