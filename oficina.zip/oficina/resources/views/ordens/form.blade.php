@extends('layouts.app')
@section('content')
@php $marcados = old('servicos', $ordem->servicos->pluck('id')->all()); @endphp
<div class="card"><div class="card-body">
    <h4 class="mb-3">{{ $ordem->exists ? 'Editar ordem #' . $ordem->id : 'Nova ordem de serviço' }}</h4>
    <form method="POST" action="{{ $ordem->exists ? route('ordens.update', $ordem->id) : route('ordens.store') }}">
        @csrf @if($ordem->exists) @method('PUT') @endif
        <div class="row g-3">
            <div class="col-md-6"><label class="form-label">Veículo</label>
                <select name="veiculo_id" class="form-select" required>
                    <option value="">Selecione...</option>
                    @foreach($veiculos as $v)
                        <option value="{{ $v->id }}" @selected(old('veiculo_id', $ordem->veiculo_id) == $v->id)>{{ $v->placa }} — {{ $v->modelo }} ({{ $v->cliente->nome }})</option>
                    @endforeach
                </select></div>
            <div class="col-md-3"><label class="form-label">Data de entrada</label>
                <input type="date" name="data_entrada" class="form-control" value="{{ old('data_entrada', optional($ordem->data_entrada)->format('Y-m-d')) }}" required></div>
            <div class="col-md-3"><label class="form-label">Status</label>
                <select name="status" class="form-select" required>
                    @foreach(\App\Models\Ordem::STATUS as $s)
                        <option value="{{ $s }}" @selected(old('status', $ordem->status) == $s)>{{ $s }}</option>
                    @endforeach
                </select></div>
            <div class="col-12"><label class="form-label">Serviços a executar</label>
                <div class="row">
                @forelse($servicos as $s)
                    <div class="col-md-4"><div class="form-check">
                        <input class="form-check-input" type="checkbox" name="servicos[]" value="{{ $s->id }}" id="s{{ $s->id }}" @checked(in_array($s->id, $marcados))>
                        <label class="form-check-label" for="s{{ $s->id }}">{{ $s->nome }} <small class="text-muted">(R$ {{ number_format($s->valor, 2, ',', '.') }})</small></label>
                    </div></div>
                @empty
                    <p class="text-muted">Cadastre serviços primeiro.</p>
                @endforelse
                </div></div>
            <div class="col-12"><label class="form-label">Observações</label>
                <textarea name="observacoes" rows="3" class="form-control">{{ old('observacoes', $ordem->observacoes) }}</textarea></div>
        </div>
        <div class="mt-4"><button class="btn btn-primary"><i class="bi bi-save"></i> Salvar</button>
            <a href="{{ route('ordens.index') }}" class="btn btn-outline-secondary">Cancelar</a></div>
    </form>
</div></div>
@endsection
