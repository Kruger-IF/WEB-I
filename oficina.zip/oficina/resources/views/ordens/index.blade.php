@extends('layouts.app')
@section('content')
<div class="card"><div class="card-body">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <h4 class="mb-0"><i class="bi bi-clipboard-check"></i> Ordens de Serviço</h4>
        <a href="{{ route('ordens.create') }}" class="btn btn-success"><i class="bi bi-plus-lg"></i> Nova ordem</a>
    </div>
    @include('layouts._search', ['placeholder' => 'Pesquisar por cliente, placa, modelo ou status...'])
    <div class="table-responsive mt-3">
    <table class="table table-hover align-middle">
        <thead><tr><th>Nº</th><th>Entrada</th><th>Cliente</th><th>Veículo</th><th>Serviços</th><th>Total</th><th>Status</th><th></th></tr></thead>
        <tbody>
        @forelse($ordens as $o)
            @php $cor = match($o->status) { 'Concluída' => 'success', 'Em andamento' => 'warning text-dark', default => 'secondary' }; @endphp
            <tr>
                <td>#{{ $o->id }}</td>
                <td>{{ $o->data_entrada->format('d/m/Y') }}</td>
                <td>{{ $o->cliente_nome }}</td>
                <td><span class="badge bg-dark">{{ $o->placa }}</span> {{ $o->modelo }}</td>
                <td>@forelse($o->servicos as $s)<span class="badge bg-info text-dark me-1">{{ $s->nome }}</span>@empty<span class="text-muted">—</span>@endforelse</td>
                <td class="fw-semibold">R$ {{ number_format($o->servicos_sum_valor ?? 0, 2, ',', '.') }}</td>
                <td><span class="badge bg-{{ $cor }}">{{ $o->status }}</span></td>
                @include('layouts._actions', ['rota' => 'ordens', 'item' => $o])
            </tr>
        @empty
            <tr><td colspan="8" class="text-center text-muted py-4">Nenhum registro encontrado.</td></tr>
        @endforelse
        </tbody>
    </table></div>
    {{ $ordens->links('pagination::bootstrap-5') }}
</div></div>
@endsection
