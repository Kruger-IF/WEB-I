<td class="text-end text-nowrap">
    <a href="{{ route($rota . '.edit', $item->id) }}" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i> Editar</a>
    <form action="{{ route($rota . '.destroy', $item->id) }}" method="POST" class="d-inline"
          onsubmit="return confirm('Tem certeza que deseja excluir?')">
        @csrf @method('DELETE')
        <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Excluir</button>
    </form>
</td>
