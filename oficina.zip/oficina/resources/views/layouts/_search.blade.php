<form method="GET" class="d-flex gap-2">
    <input type="text" name="q" value="{{ $q }}" class="form-control" placeholder="{{ $placeholder }}">
    <button class="btn btn-primary"><i class="bi bi-search"></i> Pesquisar</button>
    @if($q)<a href="{{ url()->current() }}" class="btn btn-outline-secondary">Limpar</a>@endif
</form>
