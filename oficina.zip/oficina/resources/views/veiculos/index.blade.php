@extends('layouts.app')
@section('content')
<div class="card"><div class="card-body">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <h4 class="mb-0"><i class="bi bi-car-front"></i> Veículos</h4>
        <a href="{{ route('veiculos.create') }}" class="btn btn-success"><i class="bi bi-plus-lg"></i> Novo veículo</a>
    </div>
    @include('layouts._search', ['placeholder' => 'Pesquisar por placa, marca, modelo ou dono...'])
    <div class="table-responsive mt-3">
    <table class="table table-hover align-middle">
        <thead><tr><th>Placa</th><th>Veículo</th><th>Ano</th><th>Dono</th><th>Ordens</th><th></th></tr></thead>
        <tbody>
        @forelse($veiculos as $v)
            <tr>
                <td><span class="badge bg-dark">{{ $v->placa }}</span></td>
                <td>{{ $v->marca }} {{ $v->modelo }}</td><td>{{ $v->ano }}</td>
                <td><i class="bi bi-person"></i> {{ $v->cliente_nome }}</td>
                <td><span class="badge bg-secondary">{{ $v->ordens_count }}</span></td>
                @include('layouts._actions', ['rota' => 'veiculos', 'item' => $v])
            </tr>
        @empty
            <tr><td colspan="6" class="text-center text-muted py-4">Nenhum registro encontrado.</td></tr>
        @endforelse
        </tbody>
    </table></div>
    {{ $veiculos->links('pagination::bootstrap-5') }}
</div></div>
@endsection
