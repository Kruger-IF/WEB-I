@extends('layouts.app')
@section('content')
<div class="card"><div class="card-body">
    <h4 class="mb-3">{{ $veiculo->exists ? 'Editar' : 'Novo' }} veículo</h4>
    <form method="POST" action="{{ $veiculo->exists ? route('veiculos.update', $veiculo->id) : route('veiculos.store') }}">
        @csrf @if($veiculo->exists) @method('PUT') @endif
        <div class="row g-3">
            <div class="col-md-3"><label class="form-label">Placa</label>
                <input name="placa" class="form-control" value="{{ old('placa', $veiculo->placa) }}" required></div>
            <div class="col-md-3"><label class="form-label">Marca</label>
                <input name="marca" class="form-control" value="{{ old('marca', $veiculo->marca) }}" required></div>
            <div class="col-md-4"><label class="form-label">Modelo</label>
                <input name="modelo" class="form-control" value="{{ old('modelo', $veiculo->modelo) }}" required></div>
            <div class="col-md-2"><label class="form-label">Ano</label>
                <input type="number" name="ano" class="form-control" value="{{ old('ano', $veiculo->ano) }}" required></div>
            <div class="col-md-6"><label class="form-label">Dono (cliente)</label>
                <select name="cliente_id" class="form-select" required>
                    <option value="">Selecione...</option>
                    @foreach($clientes as $c)
                        <option value="{{ $c->id }}" @selected(old('cliente_id', $veiculo->cliente_id) == $c->id)>{{ $c->nome }}</option>
                    @endforeach
                </select></div>
        </div>
        <div class="mt-4"><button class="btn btn-primary"><i class="bi bi-save"></i> Salvar</button>
            <a href="{{ route('veiculos.index') }}" class="btn btn-outline-secondary">Cancelar</a></div>
    </form>
</div></div>
@endsection
