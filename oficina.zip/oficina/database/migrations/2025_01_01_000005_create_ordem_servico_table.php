<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('ordem_servico', function (Blueprint $t) {
            $t->id();
            $t->foreignId('ordem_id')->constrained('ordens')->cascadeOnDelete();
            $t->foreignId('servico_id')->constrained('servicos')->cascadeOnDelete();
            $t->timestamps();
            $t->unique(['ordem_id', 'servico_id']);
        });
    }
    public function down(): void { Schema::dropIfExists('ordem_servico'); }
};
