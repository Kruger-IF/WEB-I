<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('servicos', function (Blueprint $t) {
            $t->id();
            $t->string('nome');
            $t->decimal('valor', 8, 2);
            $t->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('servicos'); }
};
