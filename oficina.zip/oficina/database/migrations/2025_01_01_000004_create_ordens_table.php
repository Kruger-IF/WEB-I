<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('ordens', function (Blueprint $t) {
            $t->id();
            $t->foreignId('veiculo_id')->constrained('veiculos')->cascadeOnDelete();
            $t->date('data_entrada');
            $t->string('status')->default('Aberta');
            $t->text('observacoes')->nullable();
            $t->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('ordens'); }
};
