<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('veiculos', function (Blueprint $t) {
            $t->id();
            $t->string('placa')->unique();
            $t->string('marca');
            $t->string('modelo');
            $t->unsignedSmallInteger('ano');
            $t->foreignId('cliente_id')->constrained('clientes')->cascadeOnDelete();
            $t->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('veiculos'); }
};
