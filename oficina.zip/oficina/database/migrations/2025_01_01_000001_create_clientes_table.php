<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('clientes', function (Blueprint $t) {
            $t->id();
            $t->string('nome');
            $t->string('cpf')->unique();
            $t->string('telefone');
            $t->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('clientes'); }
};
