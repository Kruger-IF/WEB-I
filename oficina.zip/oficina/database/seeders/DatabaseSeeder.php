<?php
namespace Database\Seeders;

use App\Models\Cliente;
use App\Models\Ordem;
use App\Models\Servico;
use App\Models\Veiculo;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $c1 = Cliente::create(['nome' => 'José Almeida', 'cpf' => '111.111.111-11', 'telefone' => '(53) 99111-1111']);
        $c2 = Cliente::create(['nome' => 'Fernanda Costa', 'cpf' => '222.222.222-22', 'telefone' => '(53) 99222-2222']);
        $c3 = Cliente::create(['nome' => 'Ricardo Gomes', 'cpf' => '333.333.333-33', 'telefone' => '(53) 99333-3333']);

        $v1 = Veiculo::create(['placa' => 'ABC1D23', 'marca' => 'Fiat', 'modelo' => 'Uno', 'ano' => 2015, 'cliente_id' => $c1->id]);
        $v2 = Veiculo::create(['placa' => 'DEF4G56', 'marca' => 'Volkswagen', 'modelo' => 'Gol', 'ano' => 2018, 'cliente_id' => $c1->id]);
        $v3 = Veiculo::create(['placa' => 'GHI7J89', 'marca' => 'Chevrolet', 'modelo' => 'Onix', 'ano' => 2020, 'cliente_id' => $c2->id]);
        $v4 = Veiculo::create(['placa' => 'JKL0M12', 'marca' => 'Honda', 'modelo' => 'Civic', 'ano' => 2019, 'cliente_id' => $c3->id]);

        $oleo   = Servico::create(['nome' => 'Troca de óleo', 'valor' => 120.00]);
        $freio  = Servico::create(['nome' => 'Revisão de freios', 'valor' => 250.00]);
        $alinh  = Servico::create(['nome' => 'Alinhamento e balanceamento', 'valor' => 180.00]);
        $bateria = Servico::create(['nome' => 'Troca de bateria', 'valor' => 400.00]);
        $suspensao = Servico::create(['nome' => 'Revisão de suspensão', 'valor' => 320.00]);

        $o1 = Ordem::create(['veiculo_id' => $v1->id, 'data_entrada' => now()->subDays(3), 'status' => 'Concluída', 'observacoes' => 'Cliente pediu revisão geral.']);
        $o2 = Ordem::create(['veiculo_id' => $v3->id, 'data_entrada' => now()->subDay(), 'status' => 'Em andamento', 'observacoes' => 'Barulho ao frear.']);
        $o3 = Ordem::create(['veiculo_id' => $v4->id, 'data_entrada' => now(), 'status' => 'Aberta', 'observacoes' => null]);

        $o1->servicos()->sync([$oleo->id, $alinh->id]);
        $o2->servicos()->sync([$freio->id, $suspensao->id]);
        $o3->servicos()->sync([$bateria->id]);
    }
}
