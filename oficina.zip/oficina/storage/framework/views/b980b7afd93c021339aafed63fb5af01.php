<?php $__env->startSection('content'); ?>
<div class="card"><div class="card-body">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <h4 class="mb-0"><i class="bi bi-people"></i> Clientes</h4>
        <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-success"><i class="bi bi-plus-lg"></i> Novo cliente</a>
    </div>
    <?php echo $__env->make('layouts._search', ['placeholder' => 'Pesquisar por nome, CPF ou telefone...'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="table-responsive mt-3">
    <table class="table table-hover align-middle">
        <thead><tr><th>Nome</th><th>CPF</th><th>Telefone</th><th>Veículos</th><th></th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($c->nome); ?></td><td><?php echo e($c->cpf); ?></td><td><?php echo e($c->telefone); ?></td>
                <td><span class="badge bg-secondary"><?php echo e($c->veiculos_count); ?></span></td>
                <?php echo $__env->make('layouts._actions', ['rota' => 'clientes', 'item' => $c], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" class="text-center text-muted py-4">Nenhum registro encontrado.</td></tr>
        <?php endif; ?>
        </tbody>
    </table></div>
    <?php echo e($clientes->links('pagination::bootstrap-5')); ?>

</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/victor/oficina/resources/views/clientes/index.blade.php ENDPATH**/ ?>