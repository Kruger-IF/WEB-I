<td class="text-end text-nowrap">
    <a href="<?php echo e(route($rota . '.edit', $item->id)); ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i> Editar</a>
    <form action="<?php echo e(route($rota . '.destroy', $item->id)); ?>" method="POST" class="d-inline"
          onsubmit="return confirm('Tem certeza que deseja excluir?')">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i> Excluir</button>
    </form>
</td>
<?php /**PATH /home/victor/oficina/resources/views/layouts/_actions.blade.php ENDPATH**/ ?>