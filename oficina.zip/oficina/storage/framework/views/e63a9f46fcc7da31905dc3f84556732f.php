<form method="GET" class="d-flex gap-2">
    <input type="text" name="q" value="<?php echo e($q); ?>" class="form-control" placeholder="<?php echo e($placeholder); ?>">
    <button class="btn btn-primary"><i class="bi bi-search"></i> Pesquisar</button>
    <?php if($q): ?><a href="<?php echo e(url()->current()); ?>" class="btn btn-outline-secondary">Limpar</a><?php endif; ?>
</form>
<?php /**PATH /home/victor/oficina/resources/views/layouts/_search.blade.php ENDPATH**/ ?>