<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oficina Mecânica</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background: #f3f4f6; }
        .card { border: 0; border-radius: 14px; box-shadow: 0 2px 12px rgba(0,0,0,.07); }
        .navbar { background: linear-gradient(90deg, #1f2937, #374151); border-bottom: 4px solid #f97316; }
        .navbar-brand i { color: #f97316; }
        .nav-link.active { font-weight: 600; color: #f97316 !important; }
        .btn-primary { background: #f97316; border-color: #f97316; }
        .btn-primary:hover { background: #ea580c; border-color: #ea580c; }
        th { font-size: .8rem; text-transform: uppercase; color: #6b7280; }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-md navbar-dark mb-4">
    <div class="container">
        <a class="navbar-brand" href="/"><i class="bi bi-wrench-adjustable-circle-fill me-2"></i>Oficina Mecânica</a>
        <div class="navbar-nav flex-row flex-wrap gap-3">
            <a class="nav-link <?php echo e(request()->is('ordens*') ? 'active' : ''); ?>" href="<?php echo e(route('ordens.index')); ?>"><i class="bi bi-clipboard-check"></i> Ordens</a>
            <a class="nav-link <?php echo e(request()->is('clientes*') ? 'active' : ''); ?>" href="<?php echo e(route('clientes.index')); ?>"><i class="bi bi-people"></i> Clientes</a>
            <a class="nav-link <?php echo e(request()->is('veiculos*') ? 'active' : ''); ?>" href="<?php echo e(route('veiculos.index')); ?>"><i class="bi bi-car-front"></i> Veículos</a>
            <a class="nav-link <?php echo e(request()->is('servicos*') ? 'active' : ''); ?>" href="<?php echo e(route('servicos.index')); ?>"><i class="bi bi-tools"></i> Serviços</a>
        </div>
    </div>
</nav>
<main class="container pb-5">
    <?php if(session('ok')): ?>
        <div class="alert alert-success alert-dismissible fade show"><i class="bi bi-check-circle me-1"></i> <?php echo e(session('ok')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger"><ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
</main>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH /home/victor/oficina/resources/views/layouts/app.blade.php ENDPATH**/ ?>