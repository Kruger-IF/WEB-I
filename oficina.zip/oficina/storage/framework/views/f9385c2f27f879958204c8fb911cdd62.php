<?php $__env->startSection('content'); ?>
<div class="card"><div class="card-body">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <h4 class="mb-0"><i class="bi bi-car-front"></i> Veículos</h4>
        <a href="<?php echo e(route('veiculos.create')); ?>" class="btn btn-success"><i class="bi bi-plus-lg"></i> Novo veículo</a>
    </div>
    <?php echo $__env->make('layouts._search', ['placeholder' => 'Pesquisar por placa, marca, modelo ou dono...'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="table-responsive mt-3">
    <table class="table table-hover align-middle">
        <thead><tr><th>Placa</th><th>Veículo</th><th>Ano</th><th>Dono</th><th>Ordens</th><th></th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $veiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><span class="badge bg-dark"><?php echo e($v->placa); ?></span></td>
                <td><?php echo e($v->marca); ?> <?php echo e($v->modelo); ?></td><td><?php echo e($v->ano); ?></td>
                <td><i class="bi bi-person"></i> <?php echo e($v->cliente_nome); ?></td>
                <td><span class="badge bg-secondary"><?php echo e($v->ordens_count); ?></span></td>
                <?php echo $__env->make('layouts._actions', ['rota' => 'veiculos', 'item' => $v], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" class="text-center text-muted py-4">Nenhum registro encontrado.</td></tr>
        <?php endif; ?>
        </tbody>
    </table></div>
    <?php echo e($veiculos->links('pagination::bootstrap-5')); ?>

</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/victor/oficina/resources/views/veiculos/index.blade.php ENDPATH**/ ?>