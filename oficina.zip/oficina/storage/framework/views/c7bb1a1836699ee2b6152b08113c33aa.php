<?php $__env->startSection('content'); ?>
<?php $marcados = old('servicos', $ordem->servicos->pluck('id')->all()); ?>
<div class="card"><div class="card-body">
    <h4 class="mb-3"><?php echo e($ordem->exists ? 'Editar ordem #' . $ordem->id : 'Nova ordem de serviço'); ?></h4>
    <form method="POST" action="<?php echo e($ordem->exists ? route('ordens.update', $ordem->id) : route('ordens.store')); ?>">
        <?php echo csrf_field(); ?> <?php if($ordem->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
        <div class="row g-3">
            <div class="col-md-6"><label class="form-label">Veículo</label>
                <select name="veiculo_id" class="form-select" required>
                    <option value="">Selecione...</option>
                    <?php $__currentLoopData = $veiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($v->id); ?>" <?php if(old('veiculo_id', $ordem->veiculo_id) == $v->id): echo 'selected'; endif; ?>><?php echo e($v->placa); ?> — <?php echo e($v->modelo); ?> (<?php echo e($v->cliente->nome); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select></div>
            <div class="col-md-3"><label class="form-label">Data de entrada</label>
                <input type="date" name="data_entrada" class="form-control" value="<?php echo e(old('data_entrada', optional($ordem->data_entrada)->format('Y-m-d'))); ?>" required></div>
            <div class="col-md-3"><label class="form-label">Status</label>
                <select name="status" class="form-select" required>
                    <?php $__currentLoopData = \App\Models\Ordem::STATUS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s); ?>" <?php if(old('status', $ordem->status) == $s): echo 'selected'; endif; ?>><?php echo e($s); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select></div>
            <div class="col-12"><label class="form-label">Serviços a executar</label>
                <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $servicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-4"><div class="form-check">
                        <input class="form-check-input" type="checkbox" name="servicos[]" value="<?php echo e($s->id); ?>" id="s<?php echo e($s->id); ?>" <?php if(in_array($s->id, $marcados)): echo 'checked'; endif; ?>>
                        <label class="form-check-label" for="s<?php echo e($s->id); ?>"><?php echo e($s->nome); ?> <small class="text-muted">(R$ <?php echo e(number_format($s->valor, 2, ',', '.')); ?>)</small></label>
                    </div></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">Cadastre serviços primeiro.</p>
                <?php endif; ?>
                </div></div>
            <div class="col-12"><label class="form-label">Observações</label>
                <textarea name="observacoes" rows="3" class="form-control"><?php echo e(old('observacoes', $ordem->observacoes)); ?></textarea></div>
        </div>
        <div class="mt-4"><button class="btn btn-primary"><i class="bi bi-save"></i> Salvar</button>
            <a href="<?php echo e(route('ordens.index')); ?>" class="btn btn-outline-secondary">Cancelar</a></div>
    </form>
</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/victor/oficina/resources/views/ordens/form.blade.php ENDPATH**/ ?>