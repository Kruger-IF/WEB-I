<?php $__env->startSection('content'); ?>
<div class="card"><div class="card-body">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <h4 class="mb-0"><i class="bi bi-clipboard-check"></i> Ordens de Serviço</h4>
        <a href="<?php echo e(route('ordens.create')); ?>" class="btn btn-success"><i class="bi bi-plus-lg"></i> Nova ordem</a>
    </div>
    <?php echo $__env->make('layouts._search', ['placeholder' => 'Pesquisar por cliente, placa, modelo ou status...'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="table-responsive mt-3">
    <table class="table table-hover align-middle">
        <thead><tr><th>Nº</th><th>Entrada</th><th>Cliente</th><th>Veículo</th><th>Serviços</th><th>Total</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $ordens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php $cor = match($o->status) { 'Concluída' => 'success', 'Em andamento' => 'warning text-dark', default => 'secondary' }; ?>
            <tr>
                <td>#<?php echo e($o->id); ?></td>
                <td><?php echo e($o->data_entrada->format('d/m/Y')); ?></td>
                <td><?php echo e($o->cliente_nome); ?></td>
                <td><span class="badge bg-dark"><?php echo e($o->placa); ?></span> <?php echo e($o->modelo); ?></td>
                <td><?php $__empty_2 = true; $__currentLoopData = $o->servicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?><span class="badge bg-info text-dark me-1"><?php echo e($s->nome); ?></span><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?><span class="text-muted">—</span><?php endif; ?></td>
                <td class="fw-semibold">R$ <?php echo e(number_format($o->servicos_sum_valor ?? 0, 2, ',', '.')); ?></td>
                <td><span class="badge bg-<?php echo e($cor); ?>"><?php echo e($o->status); ?></span></td>
                <?php echo $__env->make('layouts._actions', ['rota' => 'ordens', 'item' => $o], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="8" class="text-center text-muted py-4">Nenhum registro encontrado.</td></tr>
        <?php endif; ?>
        </tbody>
    </table></div>
    <?php echo e($ordens->links('pagination::bootstrap-5')); ?>

</div></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/victor/oficina/resources/views/ordens/index.blade.php ENDPATH**/ ?>