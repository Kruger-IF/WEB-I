<?php
namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Models\Veiculo;
use Illuminate\Http\Request;

class VeiculoController extends Controller
{
    public function index(Request $request)
    {
        $q = $request->input('q');

        $veiculos = Veiculo::query()
            ->join('clientes', 'clientes.id', '=', 'veiculos.cliente_id')
            ->select('veiculos.*', 'clientes.nome as cliente_nome')
            ->withCount('ordens')
            ->when($q, fn ($query) => $query->where(function ($w) use ($q) {
                $w->where('veiculos.placa', 'like', "%$q%")
                  ->orWhere('veiculos.marca', 'like', "%$q%")
                  ->orWhere('veiculos.modelo', 'like', "%$q%")
                  ->orWhere('clientes.nome', 'like', "%$q%");
            }))
            ->orderBy('veiculos.modelo')->paginate(10)->withQueryString();

        return view('veiculos.index', compact('veiculos', 'q'));
    }

    public function create()
    {
        return view('veiculos.form', ['veiculo' => new Veiculo, 'clientes' => Cliente::orderBy('nome')->get()]);
    }

    public function store(Request $request)
    {
        Veiculo::create($this->validar($request));
        return redirect()->route('veiculos.index')->with('ok', 'Veículo cadastrado com sucesso!');
    }

    public function edit(Veiculo $veiculo)
    {
        return view('veiculos.form', ['veiculo' => $veiculo, 'clientes' => Cliente::orderBy('nome')->get()]);
    }

    public function update(Request $request, Veiculo $veiculo)
    {
        $veiculo->update($this->validar($request, $veiculo->id));
        return redirect()->route('veiculos.index')->with('ok', 'Veículo atualizado com sucesso!');
    }

    public function destroy(Veiculo $veiculo)
    {
        $veiculo->delete();
        return redirect()->route('veiculos.index')->with('ok', 'Veículo excluído.');
    }

    private function validar(Request $r, $id = null): array
    {
        return $r->validate([
            'placa' => 'required|string|max:10|unique:veiculos,placa,' . $id,
            'marca' => 'required|string|max:100',
            'modelo' => 'required|string|max:100',
            'ano' => 'required|integer|min:1950|max:' . (date('Y') + 1),
            'cliente_id' => 'required|exists:clientes,id',
        ]);
    }
}
