<?php
namespace App\Http\Controllers;

use App\Models\Cliente;
use Illuminate\Http\Request;

class ClienteController extends Controller
{
    public function index(Request $request)
    {
        $q = $request->input('q');
        $clientes = Cliente::withCount('veiculos')
            ->when($q, fn ($query) => $query->where(function ($w) use ($q) {
                $w->where('nome', 'like', "%$q%")->orWhere('cpf', 'like', "%$q%")->orWhere('telefone', 'like', "%$q%");
            }))
            ->orderBy('nome')->paginate(10)->withQueryString();

        return view('clientes.index', compact('clientes', 'q'));
    }

    public function create() { return view('clientes.form', ['cliente' => new Cliente]); }

    public function store(Request $request)
    {
        Cliente::create($this->validar($request));
        return redirect()->route('clientes.index')->with('ok', 'Cliente cadastrado com sucesso!');
    }

    public function edit(Cliente $cliente) { return view('clientes.form', compact('cliente')); }

    public function update(Request $request, Cliente $cliente)
    {
        $cliente->update($this->validar($request, $cliente->id));
        return redirect()->route('clientes.index')->with('ok', 'Cliente atualizado com sucesso!');
    }

    public function destroy(Cliente $cliente)
    {
        $cliente->delete();
        return redirect()->route('clientes.index')->with('ok', 'Cliente excluído (junto com seus veículos e ordens).');
    }

    private function validar(Request $r, $id = null): array
    {
        return $r->validate([
            'nome' => 'required|string|max:255',
            'cpf' => 'required|string|max:14|unique:clientes,cpf,' . $id,
            'telefone' => 'required|string|max:20',
        ]);
    }
}
