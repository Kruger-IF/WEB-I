<?php
namespace App\Http\Controllers;

use App\Models\Servico;
use Illuminate\Http\Request;

class ServicoController extends Controller
{
    public function index(Request $request)
    {
        $q = $request->input('q');
        $servicos = Servico::withCount('ordens')
            ->when($q, fn ($query) => $query->where('nome', 'like', "%$q%"))
            ->orderBy('nome')->paginate(10)->withQueryString();

        return view('servicos.index', compact('servicos', 'q'));
    }

    public function create() { return view('servicos.form', ['servico' => new Servico]); }

    public function store(Request $request)
    {
        Servico::create($this->validar($request));
        return redirect()->route('servicos.index')->with('ok', 'Serviço cadastrado com sucesso!');
    }

    public function edit(Servico $servico) { return view('servicos.form', compact('servico')); }

    public function update(Request $request, Servico $servico)
    {
        $servico->update($this->validar($request));
        return redirect()->route('servicos.index')->with('ok', 'Serviço atualizado com sucesso!');
    }

    public function destroy(Servico $servico)
    {
        $servico->delete();
        return redirect()->route('servicos.index')->with('ok', 'Serviço excluído.');
    }

    private function validar(Request $r): array
    {
        return $r->validate([
            'nome' => 'required|string|max:255',
            'valor' => 'required|numeric|min:0',
        ]);
    }
}
