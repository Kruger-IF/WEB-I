<?php
namespace App\Http\Controllers;

use App\Models\Ordem;
use App\Models\Servico;
use App\Models\Veiculo;
use Illuminate\Http\Request;

class OrdemController extends Controller
{
    public function index(Request $request)
    {
        $q = $request->input('q');

        $ordens = Ordem::query()
            ->join('veiculos', 'veiculos.id', '=', 'ordens.veiculo_id')
            ->join('clientes', 'clientes.id', '=', 'veiculos.cliente_id')
            ->select('ordens.*', 'veiculos.placa', 'veiculos.modelo', 'clientes.nome as cliente_nome')
            ->withSum('servicos', 'valor')
            ->with('servicos')
            ->when($q, fn ($query) => $query->where(function ($w) use ($q) {
                $w->where('clientes.nome', 'like', "%$q%")
                  ->orWhere('veiculos.placa', 'like', "%$q%")
                  ->orWhere('veiculos.modelo', 'like', "%$q%")
                  ->orWhere('ordens.status', 'like', "%$q%");
            }))
            ->orderByDesc('ordens.id')->paginate(10)->withQueryString();

        return view('ordens.index', compact('ordens', 'q'));
    }

    public function create()
    {
        return view('ordens.form', $this->dadosForm(new Ordem(['data_entrada' => now(), 'status' => 'Aberta'])));
    }

    public function store(Request $request)
    {
        $ordem = Ordem::create($this->validar($request));
        $ordem->servicos()->sync($request->input('servicos', []));
        return redirect()->route('ordens.index')->with('ok', 'Ordem de serviço aberta com sucesso!');
    }

    public function edit(Ordem $ordem) { return view('ordens.form', $this->dadosForm($ordem)); }

    public function update(Request $request, Ordem $ordem)
    {
        $ordem->update($this->validar($request));
        $ordem->servicos()->sync($request->input('servicos', []));
        return redirect()->route('ordens.index')->with('ok', 'Ordem de serviço atualizada com sucesso!');
    }

    public function destroy(Ordem $ordem)
    {
        $ordem->delete();
        return redirect()->route('ordens.index')->with('ok', 'Ordem de serviço excluída.');
    }

    private function dadosForm(Ordem $ordem): array
    {
        return [
            'ordem' => $ordem,
            'veiculos' => Veiculo::with('cliente')->orderBy('modelo')->get(),
            'servicos' => Servico::orderBy('nome')->get(),
        ];
    }

    private function validar(Request $r): array
    {
        return $r->validate([
            'veiculo_id' => 'required|exists:veiculos,id',
            'data_entrada' => 'required|date',
            'status' => 'required|in:' . implode(',', Ordem::STATUS),
            'observacoes' => 'nullable|string|max:1000',
            'servicos' => 'nullable|array',
            'servicos.*' => 'exists:servicos,id',
        ]);
    }
}
