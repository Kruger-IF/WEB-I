<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Servico extends Model
{
    protected $fillable = ['nome', 'valor'];

    public function ordens() { return $this->belongsToMany(Ordem::class, 'ordem_servico')->withTimestamps(); }
}
