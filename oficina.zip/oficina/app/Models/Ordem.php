<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ordem extends Model
{
    protected $table = 'ordens';
    protected $fillable = ['veiculo_id', 'data_entrada', 'status', 'observacoes'];
    protected $casts = ['data_entrada' => 'date'];

    public const STATUS = ['Aberta', 'Em andamento', 'Concluída'];

    public function veiculo() { return $this->belongsTo(Veiculo::class); }

    public function servicos() { return $this->belongsToMany(Servico::class, 'ordem_servico')->withTimestamps(); }
}
