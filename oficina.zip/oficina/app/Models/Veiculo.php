<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Veiculo extends Model
{
    protected $fillable = ['placa', 'marca', 'modelo', 'ano', 'cliente_id'];

    public function cliente() { return $this->belongsTo(Cliente::class); }
    public function ordens() { return $this->hasMany(Ordem::class); }
}
