<?php
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\OrdemController;
use App\Http\Controllers\ServicoController;
use App\Http\Controllers\VeiculoController;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/ordens');

Route::resource('ordens', OrdemController::class)->parameters(['ordens' => 'ordem'])->except('show');
Route::resource('clientes', ClienteController::class)->parameters(['clientes' => 'cliente'])->except('show');
Route::resource('veiculos', VeiculoController::class)->parameters(['veiculos' => 'veiculo'])->except('show');
Route::resource('servicos', ServicoController::class)->parameters(['servicos' => 'servico'])->except('show');
